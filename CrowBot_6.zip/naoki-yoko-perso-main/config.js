module.exports = {
    app: {
        px: '+',
        token: '',
        owners: '898999050320363550',
        funny: '898999050320363550',
        color: 'RANDOM',
        footer: 'salahDev',
        maxserver: '6',
        everyoneMention: false,
        hostedBy: true,
        }
    }