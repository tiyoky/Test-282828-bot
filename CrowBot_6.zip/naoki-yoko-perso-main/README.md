# naoki-yoko-perso
Hey, version qui marche du naoki

# Instalation

-faite `npm i` dans le cmd ou le terminal
-faite `node index.js` **dans le terminal pour start le bot**

# Code à
https://github.com/Betaaaaaaaaaaa/naoki-yoko-perso/

# Contact Me

Discord : !salah#2200
